from django.apps import AppConfig


class IamhereConfig(AppConfig):
    name = 'iamhere'
