from django.shortcuts import render
from .order_form import KartForm

def home(request):
    return render(request, 'kart/home.html')

def order(request):
    if request.method == 'POST':
        note = 'Your order successfully placed! Have a good day!!'
        new_form = KartForm()
        return render(request, 'kart/order.html', {'colthsorder':new_form, 'note':note})
    else:
        form = KartForm()
        return render(request,'kart/order.html', {'colthsorder':form})
