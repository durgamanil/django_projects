from django import forms


class KartForm(forms.Form):
    choose1 = forms.CharField(label='First Item :', max_length=100)
    choose2 = forms.CharField(label='Second Item :', max_length=150)
    size = forms.ChoiceField(label='Size', choices=[('small','small'),('medium','medium'),('large','large')],widget=forms.RadioSelect)
