from django.apps import AppConfig


class Chess2Config(AppConfig):
    name = 'chess2'
