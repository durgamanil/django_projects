from django.apps import AppConfig


class HtmlPageTest2Config(AppConfig):
    name = 'html_page_test2'
