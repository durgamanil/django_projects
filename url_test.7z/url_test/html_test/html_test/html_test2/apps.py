from django.apps import AppConfig


class HtmlTest2Config(AppConfig):
    name = 'html_test2'
