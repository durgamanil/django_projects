from django.http import HttpResponse
#from django.urls import path,include
from django.shortcuts import render


#def home(request):
    #1+2
    #HttpResponse("<h1>this is homepage</h1>")
    #return render('',{'name':'rajini'})


#def contact(request):
#    return HttpResponse("<p>this is contactpage</p>")


#def aboutus(request):
#    return HttpResponse("<h1>about page</h1>")

