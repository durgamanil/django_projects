from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(request):
    return render(request, "home.html",{"name":"kiran"})


def add(request):
    name1 = request.POST["fname"]
    name2 = request.POST["lname"]
    paid_user="rajinikanth"
    if paid_user==name1:
        print("in if",paid_user)
        return render(request, "home.html",{"paid_user":paid_user})
    else:
        print("in else",paid_user)
        return render(request, "contact.html",{"name2":name2})
    #return render(request, "contact.html",{})